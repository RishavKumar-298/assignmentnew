package com.example3.SpringBootEmp3Application;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
@SpringBootTest
public class PersonTest {

	  @Mock
	  PersonService personservice;
	  
	  @InjectMocks
	  private PersonRepository userRepository;
	  
	  @Test
	  public void getAllEmployeesTest()
	    {
	        List<Person> list = new ArrayList<Person>();
	        Person empOne = new Person();
	      empOne.setId(1);
	      empOne.setFirstname("Nakul");
	      empOne.setLastname("Mishra");
	      empOne.setEmailId("nakul@xyz.com");
	         
	        list.add(empOne);
	         
	      Mockito.when(personservice.getAllPersons()).thenReturn(list);
	      Exception ex=Assertions.assertThrows(Exception.class, () -> personservice.getAllPersons());
	      String expected="Already present";
	      String actual=ex.getMessage();
	      Assertions.assertEquals(expected,actual);
	    }
	  @Test
	  public void getAllEmployeeByIdTest()
	    {
	        Mockito.when(personservice.getPersonById(1)).thenReturn(new Person());
	        Person emptwo= personservice.getPersonById(1);
	        assertEquals("Rahul", emptwo.getFirstname());
	        assertEquals("Sharma", emptwo.getLastname());
	        assertEquals("rahul@xyz.com", emptwo.getEmailId());
	        Exception ex=Assertions.assertThrows(Exception.class, () -> personservice.getPersonById(1));
		      String expected="Id already present";
		      String actual=ex.getMessage();
		      Assertions.assertEquals(expected,actual);
} 
}