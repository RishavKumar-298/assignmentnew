package com.example3.SpringBootEmp3Application;
import static io.restassured.RestAssured.*;
public class restAssuredTesting {
	public static void getResponseBody(){
		 
		   given().queryParam("id", "2")
		           .queryParam("firstname","martha")
		           .queryParam("lastname","sinha")
		           .queryParam("emailId", "martha@xyz.com")
		           .when().get("http://localhost:8080/person").then().log()
		           .body();
		   
		   given().queryParam("id", "3")
           .queryParam("firstname","rishav")
           .queryParam("lastname","kumar")
           .queryParam("emailId", "rishav@xyz.com")
           .when().get("http://localhost:8080/person").then().log()
           .body();
		}
}
