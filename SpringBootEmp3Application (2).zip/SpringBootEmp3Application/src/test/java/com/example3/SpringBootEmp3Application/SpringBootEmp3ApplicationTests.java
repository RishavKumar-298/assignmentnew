package com.example3.SpringBootEmp3Application;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootEmp3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
