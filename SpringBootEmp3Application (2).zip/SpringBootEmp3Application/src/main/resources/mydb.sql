create table Persons(
id integer auto_increment primary key,
firstname varchar(30),
lastname varchar(30),
emailId varchar(30)
);
insert into persons (firstname, lastname, emailId) values('amar', 'kumar', 'amar@abc.com');