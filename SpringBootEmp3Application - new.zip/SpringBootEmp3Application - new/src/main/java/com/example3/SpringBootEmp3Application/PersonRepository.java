package com.example3.SpringBootEmp3Application;

import com.example3.*;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
public interface PersonRepository extends JpaRepository<Person, Integer> {

	}
