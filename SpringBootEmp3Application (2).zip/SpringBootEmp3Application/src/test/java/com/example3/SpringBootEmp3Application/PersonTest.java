package com.example3.SpringBootEmp3Application;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
@SpringBootTest
public class PersonTest {

	  @Mock
	  PersonService personservice;
	  
	  @InjectMocks
	  private PersonRepository userRepository;
	  
	  @Test
	  public void getAllEmployeesTest()
	    {
	        List<Person> list = new ArrayList<Person>();
	        Person empOne = new Person();
	      empOne.setId(1);
	      empOne.setFirstname("Nakul");
	      empOne.setLastname("Mishra");
	      empOne.setEmailId("nakul@xyz.com");
	         
	        list.add(empOne);
	         
	      Mockito.when(personservice.getAllPersons()).thenReturn(list);
	    }
	 
} 