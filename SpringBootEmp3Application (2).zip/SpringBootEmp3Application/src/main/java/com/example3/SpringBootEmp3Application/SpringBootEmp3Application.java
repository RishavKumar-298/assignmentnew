package com.example3.SpringBootEmp3Application;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootEmp3Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootEmp3Application.class, args);
	}

}
